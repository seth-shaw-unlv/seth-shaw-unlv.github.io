#!/bin/bash

themes=( 
  stark 
  bartik
  carapace
  drupal8_parallax_theme
)
urls=(
  "http://localhost:8000/search?keys=Jerry+Jackson"
  "http://localhost:8000/search?keys=%22Las%20Vegas%22&f%5B0%5D=type%3AGeographic%20Location"
  "http://localhost:8000/search?keys=%22Hughes,%20Howard%22"
  "http://localhost:8000/search?keys=%22Spruce+Goose%22"
  "http://localhost:8000/search?keys=XF-11+Crash"
  "http://localhost:8000/search?keys=XF-11%20Crash&f%5B0%5D=subjects%3AHughes%20XF-11"
)
for theme in "${themes[@]}"
do
	# echo $theme
  drush cset -y --quiet system.theme default $theme
  for URL in "${urls[@]}"
  do
    for run in {1..5}
    do
      drush cr --quiet;
      curl -o /dev/null -sS -w "$theme\t$URL\t$run\t%{time_starttransfer}\n" $URL;
    done
  done
done