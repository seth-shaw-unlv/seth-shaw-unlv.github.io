#!/bin/bash

themes=( 
  stark 
  bartik
  carapace
  drupal8_parallax_theme
)

urls=(
http://localhost:8000/ark:/62930/d1pg1hv72 # whh000068 (complex do)
http://localhost:8000/ark:/62930/d1cf9jd5k # whh000207
http://localhost:8000/ark:/62930/d1kp7tz43 # whh000275 (complex do)
http://localhost:8000/ark:/62930/d10z7138s # whh000447
http://localhost:8000/ark:/62930/d18k7540q # whh000982 (complex do)
http://localhost:8000/ark:/62930/d1ks6jc1c # whh001590
)
for theme in "${themes[@]}"
do
	# echo $theme
  drush cset -y --quiet system.theme default $theme
  for url in "${urls[@]}"
  do
    for run in {1..5}
    do
      drush cr --quiet;
      curl -o /dev/null -sS -w "$theme\t$url\t$run\t%{time_starttransfer}\n" $url;
    done
  done
done