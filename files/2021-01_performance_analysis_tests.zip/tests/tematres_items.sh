#!/bin/bash

themes=( 
  stark 
  bartik
  carapace
  drupal8_parallax_theme
)
#random term ids between 1 and 10105 (the last term we loaded so far).
tids=(
616
2798
5325
7862
9961
)
for theme in "${themes[@]}"
do
	# echo $theme
  drush cset -y --quiet system.theme default $theme
  for tid in "${tids[@]}"
  do
    for run in {1..5}
    do
      drush cr --quiet;
      curl -o /dev/null -sS -w "$theme\tterm/$tid\t$run\t%{time_starttransfer}\n" "http://localhost:8000/taxonomy/term/$tid";
    done
  done
done